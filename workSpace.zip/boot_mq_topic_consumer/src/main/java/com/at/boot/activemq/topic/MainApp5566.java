package com.at.boot.activemq.topic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @Author: lnj999
 * @Description:
 * @Time: created on 2020/10/13 21:19
 */
@SpringBootApplication
public class MainApp5566 {
    public static void main(String[] args) {
        SpringApplication.run(MainApp5566.class, args);
    }
}
