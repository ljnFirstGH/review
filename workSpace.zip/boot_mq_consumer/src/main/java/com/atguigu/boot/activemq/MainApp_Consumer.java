package com.atguigu.boot.activemq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @Author: lnj999
 * @Description:
 * @Time: created on 2020/10/13 20:27
 */
@SpringBootApplication
public class MainApp_Consumer {
    public static void main(String[] args) {
        SpringApplication.run(MainApp_Consumer.class,args);
    }
}
