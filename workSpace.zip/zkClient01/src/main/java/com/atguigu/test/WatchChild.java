package com.atguigu.test;


import org.apache.log4j.Logger;
import org.apache.zookeeper.*;
import org.apache.zookeeper.data.Stat;

import java.io.IOException;
import java.util.List;

/**
 * @Author: lnj999
 * @Description:监控子节点
 * @Time: created on 2020/11/1 16:23
 */
public class WatchChild {
    private static final Logger logger = Logger.getLogger(WatchChild.class);
    //常量
    private static final String CONNECT_STRING = "192.168.10.130:2181";
    private static final int SESSION_TIMEOUT = 50 * 1000;
    private static final String PATH = "/atguigu";
    //实例变量
    private ZooKeeper zk = null;

    public ZooKeeper getZk() {
        return zk;
    }

    public void setZk(ZooKeeper zk) {
        this.zk = zk;
    }

    public ZooKeeper startZK() throws IOException {
        return new ZooKeeper(CONNECT_STRING, SESSION_TIMEOUT, new Watcher() {
            public void process(WatchedEvent event) {
                if (event.getType() == Event.EventType.NodeChildrenChanged && event.getPath().equals(PATH)) {
                    showChildNode(PATH );
                }else {
                    showChildNode(PATH );//注册父节点,并打印初始节点有多少个
                }

            }
        });
    }

    public void showChildNode(String path) {
        List<String> children = null;
        try {
            children = zk.getChildren(path, true);
            logger.info("*****************" + children);
        } catch (KeeperException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }


    /**
     * 1.监控我们的/atguigu节点,完成注册
     * 2.按照注册的父亲节点(/atguigu),监控下面的字几点变化(增删)
     */


    public static void main(String[] args) throws IOException, InterruptedException, KeeperException {
        WatchChild watchChild = new WatchChild();
        watchChild.setZk(watchChild.startZK());
        Thread.sleep(Long.MAX_VALUE);

    }
}
