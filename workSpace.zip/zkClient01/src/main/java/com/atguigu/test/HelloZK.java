package com.atguigu.test;


import org.apache.log4j.Logger;
import org.apache.zookeeper.*;
import org.apache.zookeeper.data.Stat;

import java.io.IOException;

/**
 * @Author: lnj999
 * @Description:
 * @Time: created on 2020/11/1 16:23
 */
public class HelloZK {
    private static final Logger logger = Logger.getLogger(HelloZK.class);
    private static final String CONNECT_STRING = "192.168.10.130:2181";
    private static final int SESSION_TIMEOUT = 50 * 1000;
    private static final String PATH = "/atguigu";

    public ZooKeeper startZK() throws IOException {
        return new ZooKeeper(CONNECT_STRING, SESSION_TIMEOUT, new Watcher() {
            public void process(WatchedEvent event) {

            }
        });
    }

    public void stopZK(ZooKeeper zk) throws InterruptedException {
        if (null != zk) {
            zk.close();
        }

    }

    public void createZnode(ZooKeeper zk, String nodePath, String nodeValue) throws KeeperException, InterruptedException {
        zk.create(nodePath, nodeValue.getBytes(), ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.PERSISTENT);
    }

    public String getZnode(ZooKeeper zk, String nodePath) throws KeeperException, InterruptedException {
        String result = null;

        byte[] zkData = zk.getData(nodePath, false, new Stat());

        result = new String(zkData);

        return result;
    }

    public static void main(String[] args) throws IOException, InterruptedException, KeeperException {
        HelloZK helloZK = new HelloZK();
        ZooKeeper zk = helloZK.startZK();

        if (zk.exists(PATH, false) == null) {
            helloZK.createZnode(zk, PATH, "hello0316");
            String retValue = helloZK.getZnode(zk, PATH);
            logger.info("*************retValue:"+retValue);
        } else {
            logger.info("*************i have this node");
        }


        helloZK.stopZK(zk);
    }
}
