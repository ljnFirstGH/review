package com.atguigu.test;


import org.apache.log4j.Logger;
import org.apache.zookeeper.*;
import org.apache.zookeeper.data.Stat;

import java.io.IOException;

/**
 * @Author: lnj999
 * @Description:一次性触发
 * @Time: created on 2020/11/1 16:23
 */
public class WatchOne {
    private static final Logger logger = Logger.getLogger(WatchOne.class);
    //常量
    private static final String CONNECT_STRING = "192.168.10.130:2181";
    private static final int SESSION_TIMEOUT = 50 * 1000;
    private static final String PATH = "/atguigu";
    //实例变量
    private ZooKeeper zk = null;

    public ZooKeeper getZk() {
        return zk;
    }

    public void setZk(ZooKeeper zk) {
        this.zk = zk;
    }

    public ZooKeeper startZK() throws IOException {
        return new ZooKeeper(CONNECT_STRING, SESSION_TIMEOUT, new Watcher() {
            public void process(WatchedEvent event) {

            }
        });
    }

    public void stopZK() throws InterruptedException {
        if (null != zk) {
            zk.close();
        }

    }

    public void createZnode(String nodePath, String nodeValue) throws KeeperException, InterruptedException {
        zk.create(nodePath, nodeValue.getBytes(), ZooDefs.Ids.OPEN_ACL_UNSAFE, CreateMode.PERSISTENT);
    }

    public String getZnode(String nodePath) throws KeeperException, InterruptedException {
        String result = null;

        byte[] zkData = zk.getData(PATH, new Watcher() {
            public void process(WatchedEvent event) {
                try {
                    trigerValue(PATH);
                } catch (KeeperException e) {
                    e.printStackTrace();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }


        }, new Stat());


        result = new String(zkData);

        return result;
    }

    private String trigerValue(String nodePath) throws KeeperException, InterruptedException {
        byte[] zkData = zk.getData(PATH, false, new Stat());
        String result = new String(zkData);
        logger.info("************Watch one time" + result);
        return result;
    }

    //监控我们的/atguigu节点,获得初次值后设置watch,只要发生新的变换,打印出最新的值,一次性watch

    public static void main(String[] args) throws IOException, InterruptedException, KeeperException {
        WatchOne watchOne = new WatchOne();
        watchOne.setZk(watchOne.startZK());

        if (watchOne.getZk().exists(PATH, false) == null) {
            watchOne.createZnode(PATH, "AAA");

            String retValue = watchOne.getZnode(PATH);
            logger.info("*************first retValue:" + retValue);

            Thread.sleep(Long.MAX_VALUE);
        } else {
            logger.info("*************i have this node");
        }


        watchOne.stopZK();
    }
}
